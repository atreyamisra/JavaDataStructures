package assignment4;

public class Dictionary {
	String[] list;
	int length;
	
	
	


	
	
	/*
	 * Getters and Setters
	 */
	public String[] getList() {
		return list;
	}
	public void setList(String[] list) {
		this.list = list;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	
	
}
