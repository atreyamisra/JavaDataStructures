Name: Atreya Misra
UTEID: am73676
Program uses basic Mastermind implementation. Partner is Connor White.  